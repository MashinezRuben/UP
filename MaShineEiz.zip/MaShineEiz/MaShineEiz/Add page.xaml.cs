﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MaShineEiz
{
    
    public partial class Add_page : Page
    {
        public ServiceCenter center = new ServiceCenter();
        private ServiceCenter centerfield = new ServiceCenter();
        int ip = 0;
        public Add_page(ServiceCenter selectedCenter)
        {
            InitializeComponent();
            Cmbfoto.ItemsSource = AppConnect.modelOdb.ServiceCenter.Select(x=> x.MainImagePath).Distinct().ToList();
            if (selectedCenter !=null)
            {
                centerfield = selectedCenter;
            }
            DataContext = centerfield;
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(ClassAddEdit.ID ==1)
                {
                    ServiceCenter servObj = new ServiceCenter()
                    {
                        MainImagePath=Convert.ToString( Cmbfoto.SelectedItem),
                       
                        //MainImagePath = tbfoto.Text,
                        Title = tbtitle.Text,
                        Cost = Convert.ToDecimal(tbcost.Text),
                        DurationInSeconds = tbsec.Text,
                        Description = tbdesc.Text,
                        Discount = Convert.ToDouble(tbvkid.Text),

                    };
                    AppConnect.modelOdb.ServiceCenter.Add(servObj);
                }
                if (ip > 0)
                {
                    centerfield.MainImagePath = center.MainImagePath;

                }
                AppConnect.modelOdb.SaveChanges();
                AppFrame.frameMain.GoBack();
            }
            catch (DbEntityValidationException ex)
            {
                MessageBox.Show("Ошибка:" + ex.Message.ToString(), "Критическая ошибка!", MessageBoxButton.OK, MessageBoxImage.Information);

            }
        }

        private void Btnblack_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.GoBack();
        }

        //private void btnviborfoto_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        var openDialog = new OpenFileDialog();
        //        openDialog.Filter = "Image files (.BMP,.JPG) | .bmp,.jpg";
        //        openDialog.Filter = "Image files (.PNG) |.png";
        //        openDialog.ShowDialog();
        //        if (openDialog.CheckFileExists && openDialog.FileName.Length > 0)
        //        {

        //            var bitmap = new BitmapImage();
        //            bitmap.BeginInit();
        //            bitmap.UriSource = new Uri(openDialog.FileName);
        //            bitmap.DecodePixelHeight = 250;
        //            bitmap.EndInit();
        //            imagebox.Source = bitmap;
        //            //center.MainImagePath = Convert.ToString( File.ReadAllBytes(openDialog.FileName));
                 

        //            ip = 1;
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        MessageBox.Show("ERROR", "Error");
        //    }
        //}  
        
        //Код для выбора своего изображения(не работает)

    }
}
