﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MaShineEiz
{
    /// <summary>
    /// Логика взаимодействия для DataGridPage.xaml
    /// </summary>
    public partial class DataGridPage : Page
    {
        public DataGridPage()
        {
            InitializeComponent();

            ServiceGrid.ItemsSource = AppConnect.modelOdb.ServiceCenter.ToList();

           
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassAddEdit.ID = 1;
            AppFrame.frameMain.Navigate(new Add_page(null));
        }

        private void BtnRedact_Click(object sender, RoutedEventArgs e)
        {
            ClassAddEdit.ID = 2;
            AppFrame.frameMain.Navigate(new Add_page((sender as Button).DataContext as ServiceCenter));

        }

        private void btnref_Click(object sender, RoutedEventArgs e)
        {
            ServiceGrid.ItemsSource = AppConnect.modelOdb.ServiceCenter.ToList();
        }
    }
}
